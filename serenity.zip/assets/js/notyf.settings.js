let notyf = new Notyf({
    duration: 1000,
    position: {
        x: 'right',
        y: 'top',
    }});
